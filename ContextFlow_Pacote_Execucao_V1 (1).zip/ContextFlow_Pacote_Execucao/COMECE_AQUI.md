# ContextFlow — entrada única para agente executor

**Status**: pacote de especificação e delegação, NÃO aplicação implementada ou homologada. Data-base: 2026-11-18.

## Objetivo
Construir ContextFlow V1: aplicativo local multiplataforma (Windows/Linux), backend Node.js + TypeScript, interface web local com Biblioteca, Leitura, Importações e Configurações; vídeos do YouTube, metadados, legendas com timestamps, resumos via provedores configuráveis e persistência local. Monólito modular; chat sobre conteúdo fica para V2.

## Ordem de leitura obrigatória
1. `docs/01-ESCOPO-CANONICO.md`: decisões e limites V1/V2.
2. `docs/02-INVESTIGACAO-E-REUSO.md`: evidências do aplicativo original, comparadores e lacunas.
3. `docs/03-ARQUITETURA-E-CONTRATOS.md`: arquitetura proposta e fronteiras.
4. `docs/04-PLANO-MESTRE.md`: execução incremental e gates.
5. `docs/05-CRITERIOS-DE-ACEITE.md`: cenários de validação.
6. `docs/06-CONTINUIDADE-E-OPERACAO.md` e `estado/ESTADO_ATUAL.md`: estado de retomada.
7. `skills/`: práticas de investigação, memória de projeto e execução autônoma; adaptar à ferramenta de destino.

## Antes de qualquer implementação
- Este ZIP contém DOCUMENTAÇÃO, não o código original: obter o repositório/ZIP `contextflow.zip` original separadamente e conferir estado/branch, dependências e dados privados.
- Fazer investigação técnica complementar E0 e registrar resultados. Comparar documentação com código, não confiar apenas em README.
- Validar decisões estruturais pendentes e obter autorização para implementação. **Este pacote isoladamente NÃO concede autorização para alteração, implantação nem publicação.**
- Ler `estado/ESTADO_ATUAL.md`, verificar HEAD e mudanças locais, e escolher a primeira fatia autorizada.
- Caso ferramenta suporte instruções de agente, usar `AGENTS.md` como entrada, seguindo estes mesmos documentos.

## Regra de execução
Executar fatias verticais com testes reais; corrigir falhas novas; registrar evidências e commits próprios; manter registros de continuidade; separar aprovação técnica de aceite humano. Não inventar funcionalidades nem declarar "100% pronto" sem evidência. Ao surgir decisão de produto/segurança/arquitetura não resolvida, parar somente a parte bloqueada e solicitar decisão objetiva.
