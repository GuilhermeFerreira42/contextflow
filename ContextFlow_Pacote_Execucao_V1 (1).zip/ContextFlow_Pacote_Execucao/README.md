# Pacote ContextFlow — para Codex / Claude Code

Pacote documental e de direção técnica. Comece por `COMECE_AQUI.md`. **Não é o executável nem inclui o projeto original**; por segurança, o código/fonte e dados originais permanecem fora deste ZIP. O agente executor necessita acesso separado à cópia adequada do repositório. Status e limites em `estado/ESTADO_ATUAL.md`.

Contém levantamento funcional, evidências preliminares, arquitetura proposta, fases, critérios de aceite e orientações de continuidade. Não há garantia de desenvolvimento autônomo irrestrito em uma única sessão; dependerá das ferramentas, permissões e retomadas do agente executor.
