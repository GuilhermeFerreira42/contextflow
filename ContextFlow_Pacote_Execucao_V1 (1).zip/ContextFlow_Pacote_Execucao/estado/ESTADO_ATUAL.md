# Estado de retomada — ContextFlow V1

**Estado deste pacote:** documentação inicial elaborada; **aplicação Node/TS não implementada**; E0 incompleta; não houve testes em Windows ou Linux nem migração. Nenhum commit de novo projeto foi produzido aqui.

## Base e evidências
- Entrada analisada: `contextflow.zip` disponibilizado pelo proprietário; leitura estática de alguns arquivos de código e docs. Não incorporado ao ZIP por conter dados locais e possivelmente segredos.
- Referências externas consultadas: READMEs dos repositórios GitHub do YouTube Learning Tracker e OpenScribe Studio. Sem clone completo, auditoria nem execução.
- Três skills de processo anexas ao pacote, preservadas do material recebido.

## Decisões de produto vindas da conversa
- Node.js + TypeScript e aplicação web local, proposta endossada, sujeita à investigação de migração;
- monólito modular, bibliotecas/leituras/importações/configurações;
- legendas YouTube priorizadas; Whisper fora de V1 obrigatória;
- leitor em planilha e texto completo como diferencial;
- chat com conteúdos reservado à V2;
- execução por fases com documentação canônica e continuidade por agentes.

## Pendências estruturais
Auditar código e dados originais em ambiente seguro, conferir licença do Learning Tracker, propor migração/versionamento, definir frontend e persistência, confirmar processos yt-dlp no Windows/Linux, aprovar plano e escrever SPEC fechada de F1.

## Próxima ação executável autorizada
**E0 investigativa e documental somente**. Para programar, agente deve solicitar autorização sobre uma fatia ou receber delegação explícita de execução do proprietário. Guardar evidências com versão/commit e separar aceite humano.

## Campos para preenchimento pelo próximo agente
- Repositório/branch/HEAD:
- Mudanças locais existentes:
- Fase em andamento e autorização:
- Verificações executadas/resultados:
- Decisões novas aprovadas:
- Arquivos/commits próprios:
- Riscos e impedimentos:
- Próxima ação:
