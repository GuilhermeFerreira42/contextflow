# Continuidade de projeto e governança de documentação

**Fonte canônica**: `docs/01-ESCOPO-CANONICO.md` + decisões autorizadas. **Estado operacional**: `estado/ESTADO_ATUAL.md`. **Evidências**: arquivo/teste/commit referenciados no estado, logs volumosos fora do Git. Não criar múltiplos status contraditórios.

## Fluxo de uma sessão nova
1. `COMECE_AQUI.md` → escopo → decisões → estado.
2. No repositório de trabalho: ler instruções, conferir branch/HEAD e alterações locais; não sobrescrever alterações de terceiros.
3. Identificar última fase tecnicamente concluída, homologação, bloqueios e próxima etapa autorizada.
4. Ler apenas especificações e código relevantes; confirmar compatibilidade dos contratos.
5. Executar fatia, testar (inclusive regressões), corrigir e documentar comprovação.
6. Registrar mudança em estado com commit/branch, arquivos, resultados, pendências e próximo passo.

## Regra de documentação
- Proposta não é decisão; código existente não prova aprovação ou comportamento funcional.
- Divergências entre código e documentação são incidentes para analisar, não justificativa para adulterar a referência aprovada.
- Não editar escopo canônico sem aprovação do proprietário. Não redefinir arquitetura fundamental unilateralmente.
- Homologação técnica e aceite humano nunca se confundem.
- Guardar credenciais/dados privados fora do repositório e dos materiais entregues.

## Ferramentas
O pacote inclui cópias das três skills de trabalho fornecidas pelo usuário. Elas são orientações de processo e podem requerer registro/instalação conforme Codex ou Claude Code; não presumir invocação automática. Nome amigável sugerido para memória: **Continuidade de Projeto** (sem alterar metadados originais da skill).
