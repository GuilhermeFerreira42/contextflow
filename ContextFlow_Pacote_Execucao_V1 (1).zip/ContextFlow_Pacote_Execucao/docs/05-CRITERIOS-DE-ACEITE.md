# Matriz inicial de aceite — adaptar por SPEC

| Cenário | Ação | Resultado verificável |
|---|---|---|
| Vídeo com legendas manuais | Importar URL | título/canal corretos, segmentos ordenados, origem e timestamps persistidos após reiniciar |
| Vídeo com apenas legendas automáticas | Importar URL | fallback usado, origem auto registrada, texto preservado |
| Vídeo sem legenda | Importar URL | erro/indisponibilidade explícita; nenhum resumo falso nem tarefa eternamente pendente |
| Playlist | Importar e repetir | itens únicos por identidade, progresso/erros individuais e sem duplicação |
| Falha de rede | Simular interrupção | job tem estado recuperável, retry não corrompe dados |
| Cancelamento | Cancelar tarefa em andamento | execução termina seguramente e dados já concluídos são preservados |
| Reabertura do app | Salvar e reiniciar | itens, transcrições, resumos e configurações não secretas persistem |
| Biblioteca grande | Popular fixture e rolar/filtrar | UI mantém responsividade, seleção por ID e linhas coerentes; metas medidas na E0 |
| Seleção múltipla | Filtrar/ordenar depois de selecionar | ações atingem somente IDs selecionados, não índices visuais deslocados |
| Leitura contínua | Expandir, buscar, abrir leitor, voltar | posição, seleção e filtros preservados; texto longo legível |
| LLM indisponível | Solicitar resumo | erro identificável e conteúdo/transcrição original intactos |
| Custos e segredos | Alterar provedor, exportar dados e logs | valores sensíveis não expostos; estimativas não apresentadas como cobranças certas |
| Migração | Importar base original sanitizada | identidade, trechos e resumos preservados; rollback documentado |
| Segurança local | Tentar URL/arquivo fora das regras | rejeição clara sem acesso arbitrário a paths ou comandos |
| Sistemas operacionais | Instalar e usar nos dois SOs | comandos reais documentados e testes separados Windows/Linux |

Os cenários são especificações de comportamento, **não provas já realizadas**. Incluir testes unitários, integração e E2E (preferir Playwright) para UI real. Registrar executado/aprovado/falhou/ignorado/não executado e homologação humana separadamente.
