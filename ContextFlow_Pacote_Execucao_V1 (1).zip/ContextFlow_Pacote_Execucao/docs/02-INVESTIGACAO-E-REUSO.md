# Investigação delimitada — relatório preliminar e E0 pendente

**Base inspecionada:** arquivo `contextflow.zip` fornecido pelo usuário, por leitura estática de fontes e documentos; repositórios públicos consultados em 2026-11-18 (README; não executados). **Não foram realizados testes runtime nem auditoria completa de licenças, dependências, segurança ou compatibilidade.** Não chamar nada de homologado.

## ContextFlow original — achados observáveis
- **Python desktop wxPython**: `main.py` instancia `wx.App` e `ui/app_window.py`; `requirements.txt` inclui `wxPython`, `yt_dlp`, `youtube-transcript-api`, `tiktoken`, `requests`.
- **Arquitetura existente**: `core/app_state.py`; `core/managers/{video,task,finance,theme}_manager.py`; `core/processor.py` com fila, `ThreadPoolExecutor`, cancelamento; `core/pubsub.py`; `storage/db_handler.py` usa SQLite e declara tabelas `videos`, `transcripts`, `ai_usage_log`, `ai_cache`, `system_config`.
- **YouTube**: `services/youtube_manager.py` usa yt-dlp, youtube_transcript_api e fallback de legendas. A presença do código não prova funcionamento atual com mudanças da API.
- **IA**: `services/ai_executor.py`, `services/ai_providers/{google,ollama}_provider.py`, governança de tokens/custos.
- **UI existente**: `ui/tab_batch.py`, `ui/tab_analysis.py`, `ui/virtual_table.py`, `ui/panel_detail.py`, `ui/dialog_config.py`. Documento `docs/CURRENT_STATE.md` descreve pipeline e contratos históricos, datado 2026-04-09; pode estar defasado.
- **Documentos antigos**: `.ai-context`, `docs/DECISION_LOG.md`, `docs/blueprint/PRD.md`, históricos; podem orientar migração, mas não são automaticamente requisitos novos. Há inconsistência de metas históricas (ex.: 5.000 versus 10.000 vídeos), a resolver por medição e decisão, não por cópia literal.
- **Privacidade**: ZIP original inclui `config/credentials.json`, bancos SQLite, thumbs e `.git/`. Não foram distribuídos neste pacote. Proteger conteúdo original e backups.

## Referências externas — evidências documentais, NÃO código auditado
- YouTube Learning Tracker: https://github.com/Samuel-025/youtube-learning-tracker — README descreve app/CLI Python + Streamlit local-first, biblioteca, coleções, metadados/transcrição, resumos, busca, Q&A e exportações. Candidato a referência de UX e fluxo; validar licença na revisão atual e testar antes de copiar código.
- OpenScribe Studio: https://github.com/michaelxer/openscribe-studio — README descreve desktop Python com faster-whisper, yt-dlp, FFmpeg; exports SRT/VTT/TXT/Markdown/JSON; licença MIT declarada no repositório. Candidato a referência de fluxo de tarefas/exportação e fallback de mídia, **não** dependência central para buscar legendas do YouTube.
- Agent Window: usar como inspiração modular futura para contexto/memória de chat. **Repositório não inspecionado nesta entrega**, portanto nenhuma alegação de reaproveitamento implementável.

## Hipóteses de reuso
1. **Reuso conceitual / migração de regras** do ContextFlow original: deduplicação, UUIDs, fila/retomada, estimativa de custos, parsing de transcrições, exportação e estados da UI; contratos devem ser reespecificados para Node/TS.
2. **Reuso direto de código Python** requer análise de integração, testes, licença e custo operacional: não presumir que vale a pena.
3. yt-dlp é ferramenta externa compatível com Node via subprocessos seguros; validar disponibilidade e comportamento em Windows/Linux; nunca interpolar URLs em shell sem escape.

## E0 — tarefas de investigação restantes e critério de parada
Verificar esquemas/migrações e dados de exemplo sanitizados; testar fluxos reais do app original em ambiente descartável; comparar repositórios com versão/commit fixado; verificar licenças/dependências, robustez de extração de legendas manual/auto e timestamps; avaliar migração de SQLite, instalações Windows/Linux e performance da tabela; inspecionar contrato básico de provedores; determinar o menor conjunto seguro de código/regras a reutilizar. Encerrar E0 ao conseguir mapear fluxos ponta a ponta, riscos e escolhas de reuso para especificar V1; NÃO fazer pesquisa ilimitada.
