# Plano mestre preliminar — V1

**Natureza:** mapa de entregas, sem quantidade final de fases congelada até E0. Cada fatia tem SPEC específica escrita/fechada antes da execução; requisites globais permanecem neste pacote.

| Etapa | Resultado observável | Dependências / Gate |
|---|---|---|
| E0 — Investigação | decisão registrada de migração/reuso, riscos, base e versões fixadas | ler código e validar fluxos; dono aprova escolhas estruturais |
| F1 — Esqueleto modular | app Node+TS inicia localmente, frontend conectado, validação em SO-alvo | E0; contratos e scripts reproduzíveis |
| F2 — Persistência e migração | biblioteca persiste vídeo e conteúdo, importa dados sanitizados sem perda | F1; backup e rollback; migrations testadas |
| F3 — Ingestão/legendas | URL/vídeo/playlist, metadados, legendas manual/auto segmentadas por tempo | F2; fluxo real com vídeo disponível/indisponível |
| F4 — Trabalhos e recuperação | fila persistente, estados, cancelamento, falhas e reexecução controlada | F3; falhas e reinício testados |
| F5 — Biblioteca | grid denso/virtualizado, filtros/pesquisa, seleção, agrupamento e ações em lote | F2–4; estabilidade com volume representativo |
| F6 — IA para resumos | provedores/configuração, resumos persistidos, custos/erros e múltiplas seleções | F2–5; chaves seguras e casos de falha |
| F7 — Leitura avançada | resumos/transcrições/ambos, expansão, leitor completo e retorno sem perda de estado | F5–6; casos de textos longos |
| F8 — Configuração, exportação e acabamento | preferências, segurança, navegação, feedback consistente, documentação do usuário | F1–7; exportação se aprovada na SPEC |
| F9 — End-to-end e entrega | smoke, regressão, dados, integração, instalação Windows/Linux e roteiro de homologação V1 | todas anteriores; aceite do escopo V1 |

A numeração é sugestiva e **não corresponde a progresso executado**. A cada fatia, preparar SPEC pequena com escopo, interfaces, erros, critérios, testes, migração/reversão, precedência documental e aprovação. Executar, validar, corrigir, registrar commit e evidências. Avançar autonomamente somente dentro da autorização. Homologação humana continua separada.

## Definição de concluído da V1
Todas as exigências V1 com evidências end-to-end, instalações verificadas em Windows e Linux ou limitação declarada, nenhum defeito crítico conhecido impedindo uso, migração protegida, documentação de uso/execução e aceite humano explícito. V2 chat não condiciona o aceite V1.
