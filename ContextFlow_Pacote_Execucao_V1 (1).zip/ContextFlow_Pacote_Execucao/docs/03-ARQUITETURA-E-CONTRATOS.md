# Arquitetura-alvo proposta — condicionada à E0

## Princípios
Monólito modular Node.js/TypeScript, aplicação local browser + API local. Módulos com responsabilidades e contratos públicos; não importarem detalhes internos entre si. Uma única fonte de verdade para cada dado. Eventos internos onde agregam valor; não reproduzir infraestrutura distribuída sem necessidade. Testabilidade e independência de UI.

## Fronteiras sugeridas
- `biblioteca`: vídeos, canais, playlists/coleções, marcações, filtros e consulta paginada/virtualizada.
- `ingestao`: aceitação de links, inspeção de vídeo/playlist, metadados, obtenção de legenda e normalização de segmentos.
- `trabalhos`: fila persistente, estados, concorrência limitada, cancelamento e retry idempotente; registra evidência de erro.
- `resumos`: orquestra prompts/modelos, processamento, proveniência, status, estimativas/custos, sem depender da UI.
- `configuracao`: preferências, endpoints, credenciais de maneira segura e versionada.
- `persistencia`: repositórios e migrações, transações; não permitir duas fontes concorrentes de verdade.
- `leitura` e `ui`: renderização virtualizada, seleção, texto completo, busca e preservação de navegação; componentes não são donos dos dados.

## Modelo de dados conceitual (não SQL final)
`Video(id interno imutável, youtubeId, title, channelId/nome, duration, url, thumbnail, playlistRefs, createdAt, ...)`; `Transcript(videoId, language, source=manual|auto|importado, status, segments:[{startMs,endMs,text}], rawArtifact?)`; `Summary(videoId, provider, model, promptVersion, transcriptRevision, text, status, error, timestamps)`; `Job(id, type, scope, status, attempts, progress, error, timestamps)`; `Collection(id,title,videoIds)`; `Preferences/Secrets` armazenados separadamente.

## Contratos de exemplo, não APIs fechadas
- `Ingestion.request(url)` retorna ID de job; `Jobs.get(jobId)` estado real persistido.
- `TranscriptRepository.find(videoId, language?)` retorna trechos ordenados com timestamps e origem.
- `Summary.request(videoIds, modelId, promptId)` retorna jobs rastreáveis e status.
- `Library.query({search, filters, sort, cursor, limit})` devolve linhas virtualizáveis com chave estável.
- Interface não executa yt-dlp ou acesso a chaves diretamente.

## Fluxos e falhas
URL → validação/normalização → deduplicação → metadados → legendas → persistir → notificação de estado → UI. Resumo processa sobre revisão persistida de transcrição. Se legenda não existe, marcar `unavailable`, sem Whisper compulsório. Em queda de rede/processo, manter jobs recuperáveis e não duplicar vídeo. Cancelamento deve ser cooperativo, evitando exclusão de dados concluídos. Chaves, dados pessoais e cookies não saem em logs nem pacote. Bind local do servidor por padrão; autenticação/restrições para exposição remota, se algum dia aprovada.

## Evolução do chat (somente previsão)
IDs de conteúdo, segmentos e revisões permitem referências de fonte. Contrato de conteúdo consultável pode ser criado quando V2 for especificada; não introduzir RAG, vetores, sessão e memória de chat antecipadamente.

## Portabilidade
Node suporta Windows/Linux, mas yt-dlp e possíveis binários FFmpeg, paths, permissões e instaladores precisam de scripts e testes reais por SO. Não prometer instalação cross-platform sem evidência.
