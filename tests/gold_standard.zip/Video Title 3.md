# Video Title 3

**URL:** http://youtube.com/watch?v=vid_3
**Canal:** Test Channel
**Duração:** 00:01:03
**Tokens:** 300

## Transcrição

Transcript content for vid_3.
Line 2.
Line 3.
